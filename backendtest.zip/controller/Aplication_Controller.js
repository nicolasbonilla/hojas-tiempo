
import UserContext from "../Context/UserContext.js"

const Controller ={
    
    'checkToken': async function(req,res,next){

        try {
            const result = await UserContext.checkToken(req)
            res.json(result)

        }
        catch (error) {
            return res.status(500).json({ "error": 500, "message": error.message })
        }

    },
    'login': async function(req,res,next){

        try {
            // obtener usuario a partir de credenciales
            const result = await UserContext.login(req)
            res.json(result)

        }
        catch (error) {
            return res.status(500).json({ "error": 500, "message": error.message })
        }

    },
    'store': async function(req,res,next){

        try {

            const result = await UserContext.store(req)
            res.json(result)

        }
        catch (error) {
            return res.status(500).json({ "error": 500, "message": error.message })
        }

    } 

}

export default Controller