import express from "express"
import Aplication_Controller from "../controller/Aplication_Controller.js"

let router = express.Router()
router.get('/checktoken',Aplication_Controller.checkToken)
router.post('/login',Aplication_Controller.login)
router.post('/store',Aplication_Controller.store)
export default router
