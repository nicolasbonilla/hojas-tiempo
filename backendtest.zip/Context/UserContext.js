import UserService from "../Services/UserService.js"

const UserContext ={

    "checkToken":async(req)=>{

        // se lee el token del header y se responde con el ususario
        //return await UserService.index_email(req)
        return {"user":{"user_id":0}}
    },

    "login":async(req)=>{

        // retorna user y token a partir de credenciales
        return {"user":{"user_id":0},"token":"DFGERGERGDFGDFG"}
    },

    "store":async(req)=>{

        // validar con jwt el usuario actual
        // se guarda el usuario nuevo
        //const newUser = await UserService.store(req)
        return {"user":{"user_id":1}}
        //return newUser
    }

}

export default UserContext