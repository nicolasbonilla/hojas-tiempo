// aqui van las consultas sql
import mysql_method from "../db/mysql.js"
const promisePool = mysql_method.pool.promise()

const UserService ={
    
    'index_email':async function(body){

        const { email } = body

        return await promisePool.query("SELECT * FROM usuarios WHERE email = ?",[email])
        .then(([rows,fields])=>{

            return { "status": true, "user": rows[0]}

        }).catch(
            console.log()
        ).finally(
            //solo si es necesario
             // await promisePool.end()
         )
    
    },

    "store": async function(body){

        const { email, password } = body
        
        return await promisePool.query(
            'INSERT INTO usuarios(email, password) VALUES(?,?)',
            [ email, password ]
        ).then(([ResultSetHeader])=>{

            return  { "status": true, "user":{ "user_id": ResultSetHeader.insertId,...body }}

        }).catch(
            console.log()
        ).finally(
           //solo si es necesario
            // await promisePool.end()
        )
    
    }
}

export default UserService
